The installation was successful.

LilGuy has been installed on your Mac. Open Terminal and type 'lilguy' to get started.

Visit [lilguy.app](https://lilguy.app) for documentation and examples.

Click Close to exit the installer.