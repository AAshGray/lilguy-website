Welcome to the LilGuy Installer

This will install LilGuy on your Mac. After installation, you can run LilGuy from Terminal using the 'lilguy' command.

Click Continue to begin the installation.